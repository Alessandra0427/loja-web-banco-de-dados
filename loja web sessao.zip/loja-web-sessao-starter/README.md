# Loja Web — Sessão e Carrinho (projeto completo)

Projeto Java Web com Maven, Servlet 4.0, JSP/EL/JSTL e Tomcat 9.

## Endpoints implementados
- `GET /produtos` — lista os produtos disponíveis.
- `GET /carrinho` — mostra o carrinho da sessão atual e seus totais.
- `POST /carrinho/itens?id={id}` — adiciona produto ou aumenta a quantidade.
- `DELETE /carrinho/itens?id={id}` — remove o produto indicado pela query string.
- `DELETE /carrinho` — limpa o carrinho da sessão.

O carrinho fica no atributo de sessão `carrinho` (`HttpSession`); não há carrinho global `static`. As JSPs usam EL/JSTL, sem scriptlets.

## Executar
1. Requisitos: JDK 21 e Maven 3.9.9+ (ou use `./mvnw`).
2. Na pasta do projeto, execute `./mvnw clean package` (Windows: `mvnw.cmd clean package`).
3. Copie `target/loja-web-sessao.war` para a pasta `webapps` do Tomcat 9.
4. Inicie o Tomcat e abra `http://localhost:8080/loja-web-sessao/`.

O ZIP também inclui um WAR previamente gerado em `target/loja-web-sessao.war` para implantação direta. A recompilação local depende de JDK/Maven compatíveis.
