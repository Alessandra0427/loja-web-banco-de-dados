<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho - Loja Web</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="topo">
    <div class="container topo-conteudo">
        <h1>Loja Web</h1>
        <nav class="menu">
            <a href="index.jsp">Início</a>
            <a href="produtos">Produtos</a>
            <a class="ativo" href="carrinho">Carrinho <span class="contador">${quantidadeTotal}</span></a>
        </nav>
    </div>
</header>

<main class="container secao">
    <div class="titulo-pagina">
        <div>
            <h2>Meu carrinho</h2>
            <p>Os produtos abaixo pertencem à sessão atual.</p>
        </div>
    </div>

    <div class="carrinho-layout">
        <section class="carrinho-produtos">
            <c:choose>
                <c:when test="${empty itensCarrinho}">
                    <div class="aviso">
                        <strong>Seu carrinho está vazio.</strong> Adicione produtos para começar sua compra.
                    </div>
                </c:when>
                <c:otherwise>
                    <c:forEach var="item" items="${itensCarrinho}">
                        <article class="item-carrinho">
                            <div class="item-icone">
                                <c:choose>
                                    <c:when test="${item.produto.id == 1}">💻</c:when>
                                    <c:when test="${item.produto.id == 2}">🖱️</c:when>
                                    <c:when test="${item.produto.id == 3}">⌨️</c:when>
                                    <c:when test="${item.produto.id == 4}">🖥️</c:when>
                                    <c:otherwise>🎧</c:otherwise>
                                </c:choose>
                            </div>
                            <div class="item-info">
                                <h3>${item.produto.nome}</h3>
                                <span>R$ <fmt:formatNumber value="${item.produto.preco}" minFractionDigits="2" maxFractionDigits="2"/></span>
                            </div>
                            <div class="quantidade"><span>Quantidade</span><strong>${item.quantidade}</strong></div>
                            <div class="subtotal"><span>Subtotal</span><strong>R$ <fmt:formatNumber value="${item.subtotal}" minFractionDigits="2" maxFractionDigits="2"/></strong></div>
                            <button class="btn-remover" type="button" data-id="${item.produto.id}">Remover</button>
                        </article>
                    </c:forEach>
                </c:otherwise>
            </c:choose>
        </section>

        <aside class="resumo">
            <h3>Resumo do pedido</h3>
            <div class="resumo-linha"><span>Itens</span><strong>${quantidadeTotal}</strong></div>
            <div class="resumo-linha total"><span>Total</span><strong>R$ <fmt:formatNumber value="${valorTotal}" minFractionDigits="2" maxFractionDigits="2"/></strong></div>
            <a class="btn btn-secundario btn-bloco" href="produtos">Continuar comprando</a>
            <button id="btn-limpar" class="btn btn-perigo btn-bloco" type="button" ${empty itensCarrinho ? 'disabled' : ''}>Limpar carrinho</button>
        </aside>
    </div>
</main>

<footer><div class="container">Programação para Web I</div></footer>

<script>
    document.querySelectorAll('.btn-remover').forEach(function (botao) {
        botao.addEventListener('click', async function () {
            const id = this.dataset.id;
            const resposta = await fetch('carrinho/itens?id=' + encodeURIComponent(id), {
                method: 'DELETE'
            });
            if (resposta.ok) {
                window.location.reload();
            } else {
                alert('Não foi possível remover o produto.');
            }
        });
    });

    const btnLimpar = document.getElementById('btn-limpar');
    if (btnLimpar) {
        btnLimpar.addEventListener('click', async function () {
            const resposta = await fetch('carrinho', { method: 'DELETE' });
            if (resposta.ok) {
                window.location.reload();
            } else {
                alert('Não foi possível limpar o carrinho.');
            }
        });
    }
</script>
</body>
</html>
