<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos - Loja Web</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="topo">
    <div class="container topo-conteudo">
        <div><h1>Loja Web</h1></div>
        <nav class="menu">
            <a href="index.jsp">Início</a>
            <a class="ativo" href="produtos">Produtos</a>
            <a href="carrinho">Carrinho</a>
        </nav>
    </div>
</header>

<main class="container secao">
    <div class="titulo-pagina">
        <div>
            <h2>Produtos</h2>
            <p>Escolha um produto para adicionar ao seu carrinho.</p>
        </div>
    </div>

    <div class="grade-produtos">
        <c:forEach var="produto" items="${produtos}">
            <article class="produto-card">
                <div class="produto-icone">
                    <c:choose>
                        <c:when test="${produto.id == 1}">💻</c:when>
                        <c:when test="${produto.id == 2}">🖱️</c:when>
                        <c:when test="${produto.id == 3}">⌨️</c:when>
                        <c:when test="${produto.id == 4}">🖥️</c:when>
                        <c:otherwise>🎧</c:otherwise>
                    </c:choose>
                </div>
                <h3>${produto.nome}</h3>
                <p class="produto-descricao">${produto.descricao}</p>
                <strong class="preco">R$ <fmt:formatNumber value="${produto.preco}" minFractionDigits="2" maxFractionDigits="2"/></strong>
                <form action="carrinho/itens" method="post">
                    <input type="hidden" name="id" value="${produto.id}">
                    <button class="btn btn-primario btn-bloco" type="submit">Adicionar ao carrinho</button>
                </form>
            </article>
        </c:forEach>
    </div>
</main>

<footer><div class="container">Programação para Web I</div></footer>
</body>
</html>
