package br.edu.ifto.web.dao;

import br.edu.ifto.web.model.Produto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProdutoMemoriaRepository {
    private final List<Produto> produtos = new ArrayList<>();

    public ProdutoMemoriaRepository() {
        produtos.add(new Produto(1, "Notebook", "Notebook para trabalho e estudos.", new BigDecimal("3500.00")));
        produtos.add(new Produto(2, "Mouse", "Mouse óptico USB.", new BigDecimal("80.00")));
        produtos.add(new Produto(3, "Teclado Mecânico", "Teclado mecânico para produtividade.", new BigDecimal("250.00")));
        produtos.add(new Produto(4, "Monitor", "Monitor para estação de trabalho.", new BigDecimal("1200.00")));
        produtos.add(new Produto(5, "Headset", "Headset para aulas e reuniões.", new BigDecimal("180.00")));
    }

    public List<Produto> listarTodos() {
        return new ArrayList<>(produtos);
    }

    public Optional<Produto> buscarPorId(Integer id) {
        return produtos.stream()
                .filter(produto -> produto.getId().equals(id))
                .findFirst();
    }
}
