package br.edu.ifto.web.servlet;

import br.edu.ifto.web.dao.ProdutoMemoriaRepository;
import br.edu.ifto.web.model.ItemCarrinho;
import br.edu.ifto.web.model.Produto;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

@WebServlet("/carrinho/itens")
public class CarrinhoItemServlet extends HttpServlet {
    private final ProdutoMemoriaRepository repository = new ProdutoMemoriaRepository();

    @SuppressWarnings("unchecked")
    private Map<Integer, ItemCarrinho> obterCarrinho(HttpSession session) {
        Map<Integer, ItemCarrinho> carrinho =
                (Map<Integer, ItemCarrinho>) session.getAttribute("carrinho");

        if (carrinho == null) {
            carrinho = new LinkedHashMap<>();
            session.setAttribute("carrinho", carrinho);
        }
        return carrinho;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String idParametro = request.getParameter("id");
        if (idParametro == null || idParametro.isBlank()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "O parâmetro id é obrigatório.");
            return;
        }

        try {
            Integer id = Integer.valueOf(idParametro);
            Produto produto = repository.buscarPorId(id).orElse(null);

            if (produto == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Produto não encontrado.");
                return;
            }

            Map<Integer, ItemCarrinho> carrinho = obterCarrinho(request.getSession());
            ItemCarrinho item = carrinho.get(id);

            if (item == null) {
                carrinho.put(id, new ItemCarrinho(produto, 1));
            } else {
                item.aumentarQuantidade();
            }

            response.sendRedirect(request.getContextPath() + "/carrinho");
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "O id deve ser numérico.");
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String idParametro = request.getParameter("id");
        if (idParametro == null || idParametro.isBlank()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "O parâmetro id é obrigatório.");
            return;
        }

        try {
            Integer id = Integer.valueOf(idParametro);
            HttpSession session = request.getSession(false);

            if (session != null) {
                Map<Integer, ItemCarrinho> carrinho =
                        (Map<Integer, ItemCarrinho>) session.getAttribute("carrinho");
                if (carrinho != null) {
                    carrinho.remove(id);
                }
            }

            response.setStatus(HttpServletResponse.SC_NO_CONTENT);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "O id deve ser numérico.");
        }
    }
}
