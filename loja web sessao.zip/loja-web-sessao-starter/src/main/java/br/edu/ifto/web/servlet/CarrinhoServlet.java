package br.edu.ifto.web.servlet;

import br.edu.ifto.web.model.ItemCarrinho;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.Map;

@WebServlet("/carrinho")
public class CarrinhoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        Map<Integer, ItemCarrinho> carrinho = Collections.emptyMap();

        if (session != null) {
            @SuppressWarnings("unchecked")
            Map<Integer, ItemCarrinho> salvo =
                    (Map<Integer, ItemCarrinho>) session.getAttribute("carrinho");
            if (salvo != null) {
                carrinho = salvo;
            }
        }

        int quantidadeTotal = carrinho.values().stream()
                .mapToInt(ItemCarrinho::getQuantidade)
                .sum();

        BigDecimal valorTotal = carrinho.values().stream()
                .map(ItemCarrinho::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        request.setAttribute("itensCarrinho", carrinho.values());
        request.setAttribute("quantidadeTotal", quantidadeTotal);
        request.setAttribute("valorTotal", valorTotal);
        request.getRequestDispatcher("/WEB-INF/views/carrinho.jsp").forward(request, response);
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.removeAttribute("carrinho");
        }
        response.setStatus(HttpServletResponse.SC_NO_CONTENT);
    }
}
